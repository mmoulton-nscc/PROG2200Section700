﻿using System;
using System.Threading;

namespace ServerChat
{
    class Program
    {
        static void Main(string[] args)
        {
            //Run as Client vs Server
            while (true)
            {
                Console.WriteLine("Listening For Messages");

                if (Console.KeyAvailable)
                {
                    //User Input Mode when I key pressed
                    ConsoleKeyInfo userKey = Console.ReadKey(); //blocking statement

                    //Display incoming message

                    //Allow for input

                    //Let user quit
                    Console.WriteLine($"You Typed {userKey.Key}");
                    Thread.Sleep(600);
                }
            }
            
        }
    }
}
