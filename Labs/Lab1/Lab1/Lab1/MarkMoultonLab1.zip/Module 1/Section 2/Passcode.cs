﻿using System;

namespace Lab1
{
    class Passcode
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your password:");
            var pass = Console.ReadLine();

            var secret = "secret";

            if (pass == secret)
            {
                Console.WriteLine("Access Granted");

                Console.WriteLine("Enter new password or enter old password to exit:");
                var secret2 = Console.ReadLine();

                if (secret2 != secret) //if password is not the old password, change it, else nothing/exit
                {
                    secret = secret2;
                }

            }
            else //else if is unnecessary
            {
                Console.WriteLine("Incorrect Password - Access Denied");
            }
        }
    }
}
