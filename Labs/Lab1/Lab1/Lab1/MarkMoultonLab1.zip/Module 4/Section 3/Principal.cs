﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    class Principal : Member, IPayee
    {
        public void Pay()
        {
            Console.WriteLine("Principal paid");
        }
    }
}
