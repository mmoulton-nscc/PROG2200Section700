﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    interface IGraduate
    {
        void graduate();
    }
}
