﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    class Stats
    {
        public void Start()
        {
            ZodiacCalculator.Posted += HasPosted;
        }

        void HasPosted()
        {
            Console.WriteLine("Survey posted, run stats");
        }
    }
}
