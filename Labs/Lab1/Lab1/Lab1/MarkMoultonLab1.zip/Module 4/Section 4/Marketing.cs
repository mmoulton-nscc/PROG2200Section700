﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    class Marketing
    {
        public void Start()
        {
            ZodiacCalculator.Posted += HasPosted;
        }

        void HasPosted()
        {
            Console.WriteLine("Thank you for completing the survey. You are now subscribed to ten of our newsletters!");
        }
    }
}
